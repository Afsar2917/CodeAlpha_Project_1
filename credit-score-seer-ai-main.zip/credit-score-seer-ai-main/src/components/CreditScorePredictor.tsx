
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/components/ui/use-toast";
import { predictCreditScore } from "@/lib/creditScoreModel";

const CreditScorePredictor = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    annualIncome: 50000,
    age: 30,
    employmentYears: 5,
    creditHistory: 5,
    outstandingDebt: 10000,
    paymentHistory: "good",
    creditUtilization: 30,
    newCreditApplications: 2,
    savingsAmount: 10000,
  });

  const handleSliderChange = (name: string, value: number[]) => {
    setFormData({
      ...formData,
      [name]: value[0],
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: parseFloat(value) || 0,
    });
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Pass the form data to our prediction model
      const result = predictCreditScore(formData);
      
      // Navigate to results page with prediction data
      navigate("/results", { state: { result, formData } });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem processing your data. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl">Credit Score Prediction</CardTitle>
        <CardDescription>
          Enter your financial information to predict your credit score.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="annualIncome">Annual Income ($)</Label>
              <Input
                id="annualIncome"
                name="annualIncome"
                type="number"
                value={formData.annualIncome}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="age">Age</Label>
              <div className="mt-1">
                <Slider
                  id="age"
                  min={18}
                  max={100}
                  step={1}
                  value={[formData.age]}
                  onValueChange={(value) => handleSliderChange("age", value)}
                />
                <div className="flex justify-between text-sm text-muted-foreground mt-1">
                  <span>18</span>
                  <span>{formData.age}</span>
                  <span>100</span>
                </div>
              </div>
            </div>
            
            <div>
              <Label htmlFor="employmentYears">Years of Employment</Label>
              <div className="mt-1">
                <Slider
                  id="employmentYears"
                  min={0}
                  max={50}
                  step={1}
                  value={[formData.employmentYears]}
                  onValueChange={(value) => handleSliderChange("employmentYears", value)}
                />
                <div className="flex justify-between text-sm text-muted-foreground mt-1">
                  <span>0</span>
                  <span>{formData.employmentYears}</span>
                  <span>50</span>
                </div>
              </div>
            </div>
            
            <div>
              <Label htmlFor="creditHistory">Years of Credit History</Label>
              <div className="mt-1">
                <Slider
                  id="creditHistory"
                  min={0}
                  max={30}
                  step={1}
                  value={[formData.creditHistory]}
                  onValueChange={(value) => handleSliderChange("creditHistory", value)}
                />
                <div className="flex justify-between text-sm text-muted-foreground mt-1">
                  <span>0</span>
                  <span>{formData.creditHistory}</span>
                  <span>30</span>
                </div>
              </div>
            </div>
            
            <div>
              <Label htmlFor="outstandingDebt">Outstanding Debt ($)</Label>
              <Input
                id="outstandingDebt"
                name="outstandingDebt"
                type="number"
                value={formData.outstandingDebt}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="paymentHistory">Payment History</Label>
              <Select
                value={formData.paymentHistory}
                onValueChange={(value) => handleSelectChange("paymentHistory", value)}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select payment history" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="excellent">Excellent</SelectItem>
                  <SelectItem value="good">Good</SelectItem>
                  <SelectItem value="fair">Fair</SelectItem>
                  <SelectItem value="poor">Poor</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="creditUtilization">Credit Utilization (%)</Label>
              <div className="mt-1">
                <Slider
                  id="creditUtilization"
                  min={0}
                  max={100}
                  step={1}
                  value={[formData.creditUtilization]}
                  onValueChange={(value) => handleSliderChange("creditUtilization", value)}
                />
                <div className="flex justify-between text-sm text-muted-foreground mt-1">
                  <span>0%</span>
                  <span>{formData.creditUtilization}%</span>
                  <span>100%</span>
                </div>
              </div>
            </div>
            
            <div>
              <Label htmlFor="newCreditApplications">Recent Credit Applications</Label>
              <Input
                id="newCreditApplications"
                name="newCreditApplications"
                type="number"
                value={formData.newCreditApplications}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="savingsAmount">Savings Amount ($)</Label>
              <Input
                id="savingsAmount"
                name="savingsAmount"
                type="number"
                value={formData.savingsAmount}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
          </div>
        </form>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSubmit} className="w-full">Predict Credit Score</Button>
      </CardFooter>
    </Card>
  );
};

export default CreditScorePredictor;
