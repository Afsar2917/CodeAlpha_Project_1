
import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface FeatureCardProps {
  title: string;
  description: string;
  icon: ReactNode;
  className?: string;
}

const FeatureCard = ({ title, description, icon, className }: FeatureCardProps) => {
  return (
    <div className={cn("feature-card relative", className)}>
      {/* Small star decoration */}
      <div className="absolute top-2 right-2 w-1 h-1 rounded-full bg-primary/60 animate-pulse"></div>
      <div className="absolute top-4 right-6 w-[3px] h-[3px] rounded-full bg-primary/40 animate-pulse" style={{ animationDelay: "0.5s" }}></div>
      
      <div className="mb-4 inline-flex items-center justify-center rounded-full bg-primary/20 p-3 text-primary ring-1 ring-primary/30">
        {icon}
      </div>
      <h3 className="text-lg font-medium bg-clip-text text-transparent bg-gradient-to-r from-foreground to-foreground/80">{title}</h3>
      <p className="mt-2 text-sm text-muted-foreground">{description}</p>
    </div>
  );
};

export default FeatureCard;
