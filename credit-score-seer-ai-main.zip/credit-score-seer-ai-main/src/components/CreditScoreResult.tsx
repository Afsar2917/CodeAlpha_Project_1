
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Info } from "lucide-react";
import { Link } from "react-router-dom";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from "recharts";
import { Tooltip as UITooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { CreditScorePrediction, UserFinancialData } from "@/types/credit";

interface CreditScoreResultProps {
  result: CreditScorePrediction;
  formData: UserFinancialData;
}

const CreditScoreResult = ({ result, formData }: CreditScoreResultProps) => {
  // Get the score band color based on the credit score
  const getScoreColor = (score: number) => {
    if (score >= 700) return "bg-credit-high";
    if (score >= 600) return "bg-credit-medium";
    return "bg-credit-low";
  };

  // Format the score as a percentage (300-850 scale, where 850 is 100%)
  const scorePercentage = Math.min(100, Math.max(0, ((result.score - 300) / 550) * 100));
  
  // Feature importance data for the chart
  const featureData = [
    { name: "Payment History", value: result.featureImportance.paymentHistory },
    { name: "Credit Utilization", value: result.featureImportance.creditUtilization },
    { name: "Credit History", value: result.featureImportance.creditHistory },
    { name: "Income", value: result.featureImportance.income },
    { name: "Debt", value: result.featureImportance.debt },
  ].sort((a, b) => b.value - a.value);

  // Custom color for each bar based on value
  const getBarColor = (value: number) => {
    if (value >= 0.3) return "#10b981"; // high importance
    if (value >= 0.15) return "#f59e0b"; // medium importance
    return "#a1a1aa"; // low importance
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Your Credit Score Prediction</CardTitle>
          <CardDescription>
            Based on the information you provided, here's your estimated credit score
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center">
            <div className="relative w-48 h-48 flex items-center justify-center rounded-full border-8 border-muted bg-background mb-4">
              <div className="text-center">
                <div className="text-4xl font-bold">{result.score}</div>
                <div className="text-sm text-muted-foreground">{result.rating}</div>
              </div>
            </div>
            
            <div className="w-full max-w-md space-y-2">
              <div className="flex justify-between text-sm">
                <span>Poor</span>
                <span>Fair</span>
                <span>Good</span>
                <span>Excellent</span>
              </div>
              <div className="score-indicator">
                <div 
                  className={`score-bar ${getScoreColor(result.score)}`}
                  style={{"--score-percentage": `${scorePercentage}%`} as React.CSSProperties}
                ></div>
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>300</span>
                <span>850</span>
              </div>
            </div>
          </div>
          
          <div>
            <div className="flex items-center mb-4">
              <h3 className="text-xl font-semibold">Factor Importance</h3>
              <TooltipProvider>
                <UITooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 ml-2 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-xs">
                      These factors influenced your credit score the most. Higher values indicate greater importance.
                    </p>
                  </TooltipContent>
                </UITooltip>
              </TooltipProvider>
            </div>
            
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={featureData}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 100, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" domain={[0, 0.5]} tickFormatter={(value) => `${Math.round(value * 100)}%`} />
                  <YAxis dataKey="name" type="category" />
                  <Tooltip 
                    formatter={(value: number) => [`${Math.round(value * 100)}%`, 'Importance']}
                  />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                    {featureData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={getBarColor(entry.value)} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          <div className="space-y-4 pt-4 border-t">
            <h3 className="text-xl font-semibold">Recommendations</h3>
            <ul className="space-y-2">
              {result.recommendations.map((rec, index) => (
                <li key={index} className="flex">
                  <div className="mr-2">•</div>
                  <div>{rec}</div>
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>
      
      <div className="flex justify-between">
        <Link to="/predict">
          <Button variant="outline" className="flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Prediction Form
          </Button>
        </Link>
        
        <Link to="/">
          <Button>
            Go to Dashboard
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default CreditScoreResult;
