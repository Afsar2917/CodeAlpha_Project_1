
import { BarChart3, Home, FileText } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

const Header = () => {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className="border-b sticky top-0 z-10 bg-background">
      <div className="container mx-auto py-4 px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <BarChart3 className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">CreditScoreSeer</span>
          </Link>
          
          <nav className="hidden md:flex space-x-6">
            <Link 
              to="/" 
              className={cn(
                "flex items-center space-x-1 text-sm font-medium transition-colors hover:text-primary",
                isActive("/") ? "text-primary" : "text-muted-foreground"
              )}
            >
              <Home className="h-4 w-4" />
              <span>Home</span>
            </Link>
            <Link 
              to="/predict" 
              className={cn(
                "flex items-center space-x-1 text-sm font-medium transition-colors hover:text-primary",
                isActive("/predict") ? "text-primary" : "text-muted-foreground"
              )}
            >
              <BarChart3 className="h-4 w-4" />
              <span>Make Prediction</span>
            </Link>
            <Link 
              to="/about" 
              className={cn(
                "flex items-center space-x-1 text-sm font-medium transition-colors hover:text-primary",
                isActive("/about") ? "text-primary" : "text-muted-foreground"
              )}
            >
              <FileText className="h-4 w-4" />
              <span>About</span>
            </Link>
          </nav>
          
          <div className="md:hidden">
            {/* Mobile menu could go here if needed */}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
