
import { Heart } from "lucide-react";

const Footer = () => {
  return (
    <footer className="border-t mt-auto">
      <div className="container mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-4 md:mb-0 text-center md:text-left">
            <span className="text-lg font-bold">CreditScoreSeer</span>
            <p className="text-sm text-muted-foreground">
              Predictive credit analysis for better financial decisions
            </p>
          </div>
          
          <div className="flex items-center justify-center text-sm text-muted-foreground">
            <span>Made with</span>
            <Heart className="h-4 w-4 mx-1 text-destructive" />
            <span>© {new Date().getFullYear()}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
