
export interface UserFinancialData {
  annualIncome: number;
  age: number;
  employmentYears: number;
  creditHistory: number;
  outstandingDebt: number;
  paymentHistory: string;
  creditUtilization: number;
  newCreditApplications: number;
  savingsAmount: number;
}

export interface FeatureImportance {
  paymentHistory: number;
  creditUtilization: number;
  creditHistory: number;
  income: number;
  debt: number;
}

export interface CreditScorePrediction {
  score: number;
  rating: string;
  probability: number;
  recommendations: string[];
  featureImportance: FeatureImportance;
}
