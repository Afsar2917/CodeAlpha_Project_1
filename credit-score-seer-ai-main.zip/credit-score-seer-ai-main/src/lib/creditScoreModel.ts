
import { CreditScorePrediction, UserFinancialData } from "@/types/credit";

// Helper function to map payment history to numeric value
const mapPaymentHistoryToValue = (paymentHistory: string): number => {
  switch (paymentHistory) {
    case "excellent": return 1.0;
    case "good": return 0.75;
    case "fair": return 0.5;
    case "poor": return 0.25;
    default: return 0.5;
  }
};

// Credit score prediction model using a decision tree-inspired approach
export const predictCreditScore = (data: UserFinancialData): CreditScorePrediction => {
  // Convert payment history to numeric value
  const paymentHistoryValue = mapPaymentHistoryToValue(data.paymentHistory);
  
  // Initialize base score (300-850 scale)
  let baseScore = 550;
  
  // Calculate feature values and importance
  const paymentHistoryFactor = paymentHistoryValue * 100; // 0-100
  const creditUtilizationFactor = Math.max(0, 100 - data.creditUtilization * 1.5); // Higher utilization = lower score
  const creditHistoryFactor = Math.min(100, data.creditHistory * 5); // Length of credit history (max 20 years)
  const incomeFactor = Math.min(100, (data.annualIncome / 100000) * 75); // Income relative to $100k
  const debtFactor = Math.max(0, 100 - (data.outstandingDebt / data.annualIncome) * 100); // Debt-to-income ratio
  const newApplicationsFactor = Math.max(0, 100 - data.newCreditApplications * 15); // New applications penalty
  const employmentFactor = Math.min(100, data.employmentYears * 5); // Employment history
  const ageFactor = Math.min(100, (data.age - 18) * 2); // Age factor (minus 18 as minimum)
  const savingsFactor = Math.min(100, (data.savingsAmount / 50000) * 50); // Savings relative to $50k
  
  // Weight the factors according to general credit score models
  const weightedScore = (
    paymentHistoryFactor * 0.35 +
    creditUtilizationFactor * 0.30 +
    creditHistoryFactor * 0.15 +
    incomeFactor * 0.05 +
    debtFactor * 0.05 +
    newApplicationsFactor * 0.05 +
    employmentFactor * 0.03 +
    ageFactor * 0.01 +
    savingsFactor * 0.01
  );
  
  // Scale to credit score range (300-850)
  const finalScore = Math.round(300 + (weightedScore * 5.5));
  
  // Add some randomness to simulate real-world variation (±20 points)
  const randomVariation = Math.round((Math.random() - 0.5) * 40);
  const score = Math.max(300, Math.min(850, finalScore + randomVariation));
  
  // Determine credit rating
  let rating = "";
  if (score >= 750) {
    rating = "Excellent";
  } else if (score >= 700) {
    rating = "Very Good";
  } else if (score >= 650) {
    rating = "Good";
  } else if (score >= 600) {
    rating = "Fair";
  } else if (score >= 550) {
    rating = "Poor";
  } else {
    rating = "Very Poor";
  }
  
  // Generate recommendations based on the weakest factors
  const recommendations: string[] = [];
  
  if (paymentHistoryFactor < 75) {
    recommendations.push("Improve your payment history by ensuring all bills are paid on time.");
  }
  
  if (data.creditUtilization > 30) {
    recommendations.push("Reduce your credit utilization ratio to below 30% by paying down revolving credit balances.");
  }
  
  if (creditHistoryFactor < 50) {
    recommendations.push("Continue to maintain older credit accounts to build credit history length.");
  }
  
  if (data.outstandingDebt / data.annualIncome > 0.4) {
    recommendations.push("Work on reducing your debt-to-income ratio by paying down existing debts.");
  }
  
  if (data.newCreditApplications > 2) {
    recommendations.push("Limit new credit applications as they can temporarily lower your credit score.");
  }
  
  if (data.savingsAmount < 5000) {
    recommendations.push("Build up your emergency savings to improve financial stability.");
  }
  
  // If no specific recommendations, provide a general one
  if (recommendations.length === 0) {
    recommendations.push("Continue your good financial habits to maintain your excellent credit score.");
  }
  
  // Calculate feature importance (based on how much each factor contributed to the final score)
  const featureImportance = {
    paymentHistory: 0.35,
    creditUtilization: 0.30,
    creditHistory: 0.15,
    income: 0.10,
    debt: 0.10
  };
  
  // Return the prediction result
  return {
    score,
    rating,
    probability: 0.85, // Model confidence (fixed for simplicity)
    recommendations,
    featureImportance
  };
};
