
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { BarChart3, CloudLightning, LineChart, PieChart, ShieldCheck, TrendingUp } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FeatureCard from "@/components/FeatureCard";

const Index = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1">
        {/* Hero section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-accent">
          <div className="container mx-auto max-w-6xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-foreground">
                  Predict Your <span className="text-primary">Credit Score</span> with AI
                </h1>
                <p className="mt-4 text-lg text-muted-foreground max-w-xl">
                  CreditScoreSeer uses advanced machine learning to analyze your financial data and provide accurate credit score predictions and personalized recommendations.
                </p>
                <div className="mt-8 flex flex-wrap gap-4">
                  <Link to="/predict">
                    <Button size="lg" className="font-semibold">
                      Get Your Prediction
                    </Button>
                  </Link>
                  <Link to="/about">
                    <Button size="lg" variant="outline" className="font-semibold">
                      Learn More
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="hidden md:flex justify-center">
                <div className="relative w-72 h-72 bg-primary/10 rounded-full flex items-center justify-center">
                  <BarChart3 className="h-32 w-32 text-primary" />
                  <div className="absolute -top-4 -right-4 bg-accent rounded-full p-4">
                    <TrendingUp className="h-8 w-8 text-primary" />
                  </div>
                  <div className="absolute -bottom-6 -left-6 bg-accent rounded-full p-4">
                    <ShieldCheck className="h-8 w-8 text-primary" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Features section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="container mx-auto">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <h2 className="text-3xl font-bold">Why Choose CreditScoreSeer?</h2>
              <p className="mt-4 text-muted-foreground">
                Our AI-powered platform offers accurate predictions and actionable insights to help improve your financial health.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <FeatureCard
                title="Advanced AI Model"
                description="Powered by machine learning algorithms trained on extensive financial data for accurate predictions."
                icon={<CloudLightning className="h-6 w-6" />}
              />
              <FeatureCard
                title="Real-time Analysis"
                description="Get instant credit score predictions based on your current financial situation."
                icon={<BarChart3 className="h-6 w-6" />}
              />
              <FeatureCard
                title="Personalized Recommendations"
                description="Receive tailored advice to improve your credit score based on your unique financial profile."
                icon={<ShieldCheck className="h-6 w-6" />}
              />
              <FeatureCard
                title="Comprehensive Insights"
                description="Understand the key factors affecting your credit score through detailed visualizations."
                icon={<PieChart className="h-6 w-6" />}
              />
              <FeatureCard
                title="Financial Trend Analysis"
                description="Track your progress over time and see how different factors impact your credit health."
                icon={<LineChart className="h-6 w-6" />}
              />
              <FeatureCard
                title="Future Projections"
                description="Estimate how future financial decisions might impact your credit score."
                icon={<TrendingUp className="h-6 w-6" />}
              />
            </div>
          </div>
        </section>
        
        {/* CTA section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-accent">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-3xl font-bold">Ready to See Your Credit Score?</h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
              Get your personalized credit score prediction in minutes. No credit check required.
            </p>
            <div className="mt-8">
              <Link to="/predict">
                <Button size="lg" className="font-semibold">
                  Start Your Prediction
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Index;
