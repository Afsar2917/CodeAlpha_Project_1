
import CreditScorePredictor from "@/components/CreditScorePredictor";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const PredictPage = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-1 py-12 px-4 sm:px-6 lg:px-8 bg-accent/10 relative">
        {/* Galaxy decoration elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-1/4 w-1 h-1 rounded-full bg-primary animate-twinkle"></div>
          <div className="absolute top-40 right-1/3 w-2 h-2 rounded-full bg-primary/70 animate-twinkle" style={{ animationDelay: "1.5s" }}></div>
          <div className="absolute bottom-1/4 left-1/5 w-1 h-1 rounded-full bg-primary/60 animate-twinkle" style={{ animationDelay: "0.8s" }}></div>
          <div className="absolute bottom-32 right-1/4 w-[3px] h-[3px] rounded-full bg-primary/80 animate-twinkle" style={{ animationDelay: "2s" }}></div>
        </div>
        
        <div className="container mx-auto relative z-10">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary via-foreground/90 to-primary/80">Predict Your Credit Score</h1>
              <p className="mt-2 text-muted-foreground">
                Fill out the form below with your financial information to get a prediction of your credit score.
              </p>
            </div>
            <CreditScorePredictor />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default PredictPage;
