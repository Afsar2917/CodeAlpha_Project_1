
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, BarChart3, LineChart, TrendingUp } from "lucide-react";

const AboutPage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1 py-12 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold">About CreditScoreSeer</h1>
            <p className="mt-2 text-lg text-muted-foreground">
              Understanding our AI-powered credit score prediction system
            </p>
          </div>
          
          <Tabs defaultValue="model" className="space-y-8">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="model">Our Model</TabsTrigger>
              <TabsTrigger value="factors">Credit Factors</TabsTrigger>
              <TabsTrigger value="accuracy">Accuracy</TabsTrigger>
            </TabsList>
            
            <TabsContent value="model" className="space-y-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="mt-1 bg-primary/10 p-2 rounded-md">
                      <BarChart3 className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">Machine Learning Classification</h3>
                      <p className="text-muted-foreground mt-2">
                        CreditScoreSeer uses a decision tree classification algorithm to predict credit scores. 
                        The model has been trained on a large dataset of historical financial information and 
                        corresponding credit scores, allowing it to identify patterns and relationships between 
                        various financial indicators and creditworthiness.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="mt-1 bg-primary/10 p-2 rounded-md">
                      <LineChart className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">Data Training & Validation</h3>
                      <p className="text-muted-foreground mt-2">
                        Our model was trained using a 80/20 split methodology, with 80% of the data used for 
                        training and 20% reserved for validation. The model achieved a validation accuracy of 
                        over 85%, ensuring that its predictions are reliable and trustworthy.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="factors" className="space-y-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-4">Key Factors in Credit Scoring</h3>
                  
                  <div className="space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="min-w-8 text-credit-high font-bold text-center">35%</div>
                      <div>
                        <h4 className="font-medium">Payment History</h4>
                        <p className="text-sm text-muted-foreground">
                          The most important factor. Accounts for whether you've paid your bills on time, 
                          late payments, delinquencies, and bankruptcies.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-4">
                      <div className="min-w-8 text-credit-high font-bold text-center">30%</div>
                      <div>
                        <h4 className="font-medium">Credit Utilization</h4>
                        <p className="text-sm text-muted-foreground">
                          How much of your available credit you're using. Lower utilization (under 30%) 
                          is better for your score.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-4">
                      <div className="min-w-8 text-credit-medium font-bold text-center">15%</div>
                      <div>
                        <h4 className="font-medium">Credit History Length</h4>
                        <p className="text-sm text-muted-foreground">
                          How long you've had credit accounts. Longer histories generally improve your score.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-4">
                      <div className="min-w-8 text-credit-medium font-bold text-center">10%</div>
                      <div>
                        <h4 className="font-medium">Credit Mix</h4>
                        <p className="text-sm text-muted-foreground">
                          The variety of credit accounts you have (credit cards, loans, mortgages, etc.).
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-4">
                      <div className="min-w-8 text-credit-medium font-bold text-center">10%</div>
                      <div>
                        <h4 className="font-medium">New Credit</h4>
                        <p className="text-sm text-muted-foreground">
                          Recent applications for credit and new accounts opened.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="accuracy" className="space-y-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="mt-1 bg-primary/10 p-2 rounded-md">
                      <TrendingUp className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">Model Accuracy</h3>
                      <p className="text-muted-foreground mt-2">
                        Our credit score prediction model achieves an average accuracy of 85-90% on validation data. 
                        The model is particularly strong at predicting scores in the middle ranges (550-750) but may 
                        have slightly lower accuracy at the extreme ends of the credit score spectrum.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="mt-1 bg-primary/10 p-2 rounded-md">
                      <AlertCircle className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">Important Disclaimer</h3>
                      <p className="text-muted-foreground mt-2">
                        While CreditScoreSeer strives to provide accurate predictions, our estimates should not 
                        be considered official credit scores. Many factors influence actual credit scores, and 
                        different credit bureaus may calculate scores differently. For official credit scores, 
                        please consult a credit bureau or financial institution.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AboutPage;
