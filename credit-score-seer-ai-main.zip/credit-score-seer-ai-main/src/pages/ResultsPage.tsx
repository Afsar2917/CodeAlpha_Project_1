
import { useLocation, Navigate } from "react-router-dom";
import CreditScoreResult from "@/components/CreditScoreResult";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { CreditScorePrediction, UserFinancialData } from "@/types/credit";

const ResultsPage = () => {
  const location = useLocation();
  const state = location.state as { result: CreditScorePrediction; formData: UserFinancialData } | null;
  
  // If no result data, redirect to prediction page
  if (!state || !state.result) {
    return <Navigate to="/predict" replace />;
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1 py-12 px-4 sm:px-6 lg:px-8 bg-accent/20">
        <div className="container mx-auto">
          <CreditScoreResult result={state.result} formData={state.formData} />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ResultsPage;
